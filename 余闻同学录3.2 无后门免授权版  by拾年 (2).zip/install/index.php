<!DOCTYPE html>
<html lang="en">
	<head>
		<!-- Basic -->
    	<meta charset="UTF-8" />
    <title>余闻同学录3.2 拾年破解版-安装</title>
		<!-- Mobile Metas -->
	    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />       
		<!-- Favicon and touch icons -->
	    <!-- start: CSS file-->
		<!-- Vendor CSS-->
		<link href="/assets/css/bootstrap.min.css" rel="stylesheet" />
		<link href="/assets/css/skycons.css" rel="stylesheet" />
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">
		
		<!-- Plugins CSS-->		
		
		<!-- Theme CSS -->
		<link href="/assets/css/jquery.mmenu.css" rel="stylesheet" />
		
		<!-- Page CSS -->		
		<link href="/assets/css/style.css" rel="stylesheet" />
		<link href="/assets/css/add-ons.min.css" rel="stylesheet" />
		<div class="container-fluid content">
			<div class="row">
				<!-- Main Page -->
				<div class="body-login">
					<div class="center-login">
						<div class="panel panel-login">
							<div class="panel-title-login text-right">
							</div>
							<div class="panel-body">
<?php
@header('Content-Type: text/html; charset=UTF-8');
if(file_exists('install.lock')){
    exit('已经安装完成！如需重新安装，请删除install目录下的install.lock!');
}
$step = isset($_GET['step'])?$_GET['step']:0x001;
$action = isset($_POST['action'])?$_POST['action']:null;
$finish = 1;
if($action == 'install'){
    $host = isset($_POST['host'])?$_POST['host']:null;
    $port = isset($_POST['port'])?$_POST['port']:null;
    $user = isset($_POST['user'])?$_POST['user']:null;
    $pwd = isset($_POST['pwd'])?$_POST['pwd']:null;
    $database = isset($_POST['database'])?$_POST['database']:null;
    if(empty($host) || empty($port) || empty($user) || empty($database)){
        $errorMsg = '请填完所有数据库信息';
    }else{
        $mysql['host'] = $host;
        $mysql['port'] = $port;
        $mysql['database'] = $database;
        $mysql['username'] = $user;
        $mysql['password'] = $pwd;
        try{
            $db = new PDO('mysql:host=' . $mysql['host'] . ';dbname=' . $mysql['database'] . ';port=' . $mysql['port'], $mysql['username'], $mysql['password']);
        }
        catch(Exception$e){
            $errorMsg = '链接数据库失败:' . $e -> getMessage();
        }
        $domians = explode('.', $_SERVER['HTTP_HOST']);
        $domians = array_reverse($domians);
        if(empty($errorMsg)){
            $config['db'] = $mysql;
            $data = "<?php
return array(
	'DB_HOST'               =>  '{$host}',
    'DB_NAME'               =>  '{$database}',
    'DB_USER'               =>  '{$user}',
    'DB_PWD'                =>  '{$pwd}',
    'DB_PORT'               =>  '{$port}',
    'DB_PREFIX'             =>  'ssnh_',
);";
            @file_put_contents('../admin/db.php', $data);
            $db -> exec('set names utf8');
            $sqls = file_get_contents('install.sql');
            $sqls = explode(';', $sqls);
            $success = 0;
            $error = 0;
            $errorMsg = null;
            foreach($sqls as $value){
                $length = trim($value);
                if(!empty($length)){
                    if($db -> exec($value) === false){
                        $error++;
                        $dberror = $db -> errorInfo();
                        $errorMsg .= $dberror[2] . '<br>';
                    }else{
                        $success++;
                    }
                }
            }
            $step = 3;
            @file_put_contents('install.lock', '');
        }
    }
}
?>
<?php
 if(isset($errorMsg)){
    echo '<div class="alert alert-danger text-center" role="alert">' . $errorMsg . '</div>';
}
if($step == 2){
    ?>
		         
                <h3 class="text-center pv">余闻3.2破解版</h3>
                <form class="form-horizontal mb-lg" action="#" method="post">
                    <input type="hidden" name="action" class="form-control" value="install">
                    <label for="name">数据库地址:</label>
                    <input type="text" class="form-control" name="host" value="localhost">
                    <label for="name">数据库端口:</label>
                    <input type="text" class="form-control" name="port" value="3306">
                    <label for="name">数据库库名:</label>
                    <input type="text" class="form-control" name="database" placeholder="输入数据库库名">
                    <label for="name">数据库用户名:</label>
                    <input type="text" class="form-control" name="user" placeholder="输入数据库用户名">
                    <label for="name">数据库密码:</label>
                    <input type="password" class="form-control" name="pwd" placeholder="输入数据库密码">
                    <br><input type="submit" class="btn btn-primary btn-block" name="submit" value="确认，下一步">
                </form>

            </div>

<?php }elseif($step == 3){
    ?>
    
            <div class="form-signin">
                <div class="center-login">
                       <h2 class="text-center pv">网站安装成功</h2>
                    <p>共导入
<?php echo($success + $error);
    ?>条数据 成功:<?php echo $success?>条 失败:<?php echo $error?>条</p>
                    <p>管理员账号admin，密码123456，请尽快修改密码。</p>
                    <p><a href="/index.php">网站首页</a></p>
                </div>
            </div>
        </div>

<?php }else{
    ?>
            <form action="?step=2" class="form-signin" method="post">
                <div id="error">
                        <h2 class="text-center pv">余闻同学录3.2说明</h2>
                        <br>
                        <p>1.本程序由拾年破解</p>
                        <p>2.本源码已去除所有后门漏洞，可放心使用。</p>
                        <p>3.拾年QQ1002879459</p>
                        <p style="color:red">4.我只负责破解，除有后门外，其余事情一概不进行处理。</p>
                        <button type="submit" class="btn btn-primary block full-width">我已阅读,并同意以上条款</button>
<br>
	<br>
		<br>
	   <span>&copy;</span>
            <span>2016</span>
            <span>-</span>
            <span>似水年华</span>
</div>
                    </div>
                </div>
            </form>
        </div>

<?php }
?>
        </div>
    </div>
</div>
</body>
</html>